# Edexcel A-Level Maths Revision

Open `index.html` in a browser. Upload the project to GitHub and enable GitHub Pages to publish it.

The site includes separate Pure, Statistics and Mechanics topic areas, difficulty modes and mixed practice tests. The questions in this starter bank are generated from templates and are not official Pearson exam papers.
