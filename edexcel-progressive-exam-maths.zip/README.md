# Edexcel A-Level Maths Progressive Exam Practice

Upload `index.html` to the root of a GitHub repository and enable GitHub Pages (Settings → Pages → Deploy from a branch → main → /(root)).

This is an independent revision resource with progressive topic ladders, worked solutions, mixed practice and a paper builder. Questions are original practice questions, not official Pearson Edexcel past papers. Some less common specification topics currently use structured practice prompts rather than a fully worked randomised question bank.
